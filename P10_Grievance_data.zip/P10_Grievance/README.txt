PROJECT 10: Public Grievance Redressal and Complaint Tracking System
======================================================================

Tables: 11   Total rows: 350,972

LOAD ORDER (parents before children) and ROW COUNTS
----------------------------------------------------------------------
 1. departments                   20 rows   [reference table]
 2. complaint_types               69 rows   [reference table]
 3. wards                        150 rows   [reference table]
 4. locations                  3,000 rows
 5. citizens                  25,000 rows
 6. officers                   1,500 rows
 7. complaints                50,000 rows
 8. status_history           198,366 rows
 9. assignments               49,742 rows
10. escalations                4,177 rows
11. feedback                  18,948 rows

COLUMNS
----------------------------------------------------------------------
departments  --  Reference table of municipal departments
    department_id             INT  [PK]
    name                      VARCHAR(40)

complaint_types  --  Complaint types with their SLA in hours
    type_id                   INT  [PK]
    department_id             INT  [FK -> departments.department_id]
    name                      VARCHAR(50)
    sla_hours                 INT

wards  --  Municipal wards grouped into zones
    ward_id                   INT  [PK]
    name                      VARCHAR(40)
    zone_no                   INT

locations  --  Addresses where complaints are reported
    location_id               INT  [PK]
    ward_id                   INT  [FK -> wards.ward_id]
    address_line              VARCHAR(80)
    pincode                   VARCHAR(6)
    latitude                  NUMERIC(9,6)
    longitude                 NUMERIC(9,6)

citizens  --  Citizens who file complaints
    citizen_id                INT  [PK]
    full_name                 VARCHAR(80)
    phone                     VARCHAR(12)
    email                     VARCHAR(80)
    ward_id                   INT  [FK -> wards.ward_id]
    is_anonymous              BOOLEAN
    registered_on             DATE

officers  --  Officers with a supervisor hierarchy (Commissioner > Head > Zonal > Field)
    officer_id                INT  [PK]
    full_name                 VARCHAR(80)
    department_id             INT  [FK -> departments.department_id]
    supervisor_id             INT  [FK -> officers.officer_id]
    designation               VARCHAR(30)
    ward_id                   INT  [FK -> wards.ward_id]
    is_active                 BOOLEAN

complaints  --  Citizen complaints with description and resolution notes
    complaint_id              INT  [PK]
    citizen_id                INT  [FK -> citizens.citizen_id]
    type_id                   INT  [FK -> complaint_types.type_id]
    location_id               INT  [FK -> locations.location_id]
    title                     VARCHAR(80)
    description               TEXT
    channel                   VARCHAR(10)
    priority                  VARCHAR(8)
    created_at                TIMESTAMP
    closed_at                 TIMESTAMP
    status                    VARCHAR(12)
    resolution_notes          TEXT

status_history  --  Every status change of every complaint
    history_id                INT  [PK]
    complaint_id              INT  [FK -> complaints.complaint_id]
    old_status                VARCHAR(12)
    new_status                VARCHAR(12)
    changed_at                TIMESTAMP
    changed_by_officer_id     INT  [FK -> officers.officer_id]

assignments  --  Which officer handled which complaint (reassignments create new rows)
    assignment_id             INT  [PK]
    complaint_id              INT  [FK -> complaints.complaint_id]
    officer_id                INT  [FK -> officers.officer_id]
    assigned_at               TIMESTAMP
    released_at               TIMESTAMP

escalations  --  Escalation to the supervisor when SLA is missed
    escalation_id             INT  [PK]
    complaint_id              INT  [FK -> complaints.complaint_id]
    from_officer_id           INT  [FK -> officers.officer_id]
    to_officer_id             INT  [FK -> officers.officer_id]
    reason                    VARCHAR(20)
    escalated_at              TIMESTAMP

feedback  --  Citizen feedback after closure
    feedback_id               INT  [PK]
    complaint_id              INT  [FK -> complaints.complaint_id]
    rating                    INT
    comment                   VARCHAR(120)
    created_at                TIMESTAMP

HOW TO LOAD
----------------------------------------------------------------------
1. CREATE DATABASE project_db;   then design and CREATE TABLE statements yourself (PK, FK, CHECK, UNIQUE).
2. Load each CSV in the order above:
   \copy table_name FROM 'table_name.csv' WITH (FORMAT csv, HEADER true);
   (empty cells are NULL; booleans are true/false; dates are YYYY-MM-DD; timestamps are YYYY-MM-DD HH:MM:SS)
3. After loading, run ANALYZE; and verify row counts against this file.
