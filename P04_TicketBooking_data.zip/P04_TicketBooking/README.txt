PROJECT 04: Event and Movie Ticket Booking with Seat Concurrency
======================================================================

Tables: 13   Total rows: 449,958

LOAD ORDER (parents before children) and ROW COUNTS
----------------------------------------------------------------------
 1. genres                        18 rows   [reference table]
 2. movies                     3,000 rows
 3. movie_genres               6,028 rows
 4. theatres                   1,000 rows
 5. screens                    1,500 rows
 6. seats                    104,444 rows
 7. users                     12,000 rows
 8. shows                      8,000 rows
 9. bookings                  64,425 rows
10. booking_seats            140,518 rows
11. payments                  64,425 rows
12. ratings                   42,000 rows
13. waitlist                   2,600 rows

COLUMNS
----------------------------------------------------------------------
genres  --  Reference table of genres
    genre_id                  INT  [PK]
    genre_name                VARCHAR(20)

movies  --  Movie catalogue
    movie_id                  INT  [PK]
    title                     VARCHAR(80)
    release_year              INT
    language                  VARCHAR(12)
    duration_min              INT
    certificate               VARCHAR(4)
    popularity                INT

movie_genres  --  Movies and their genres (many-to-many)
    movie_id                  INT  [PK/FK -> movies.movie_id]
    genre_id                  INT  [PK/FK -> genres.genre_id]

theatres  --  Cinemas
    theatre_id                INT  [PK]
    name                      VARCHAR(80)
    city                      VARCHAR(40)
    state                     VARCHAR(40)
    address                   VARCHAR(100)
    pincode                   VARCHAR(6)

screens  --  Screens inside theatres
    screen_id                 INT  [PK]
    theatre_id                INT  [FK -> theatres.theatre_id]
    screen_name               VARCHAR(20)
    seat_rows                 INT
    seats_per_row             INT
    capacity                  INT
    screen_type               VARCHAR(10)

seats  --  Physical seats of every screen
    seat_id                   INT  [PK]
    screen_id                 INT  [FK -> screens.screen_id]
    row_label                 CHAR(1)
    seat_no                   INT
    category                  VARCHAR(10)

users  --  Registered customers
    user_id                   INT  [PK]
    full_name                 VARCHAR(80)
    email                     VARCHAR(80)
    phone                     VARCHAR(12)
    city                      VARCHAR(40)
    joined_on                 DATE

shows  --  Scheduled shows; no overlap on the same screen
    show_id                   INT  [PK]
    movie_id                  INT  [FK -> movies.movie_id]
    screen_id                 INT  [FK -> screens.screen_id]
    show_start                TIMESTAMP
    show_end                  TIMESTAMP
    base_price                NUMERIC(6,2)

bookings  --  Ticket bookings (confirmed or cancelled)
    booking_id                INT  [PK]
    user_id                   INT  [FK -> users.user_id]
    show_id                   INT  [FK -> shows.show_id]
    booked_at                 TIMESTAMP
    seats_count               INT
    status                    VARCHAR(10)
    total_amount              NUMERIC(8,2)
    cancelled_at              TIMESTAMP

booking_seats  --  Seats sold per booking; UNIQUE (show_id, seat_id) must hold
    booking_id                INT  [PK/FK -> bookings.booking_id]
    show_id                   INT  [FK -> shows.show_id]
    seat_id                   INT  [PK/FK -> seats.seat_id]
    price                     NUMERIC(8,2)

payments  --  One payment per booking
    payment_id                INT  [PK]
    booking_id                INT  [FK -> bookings.booking_id]
    method                    VARCHAR(12)
    amount                    NUMERIC(8,2)
    status                    VARCHAR(10)
    paid_at                   TIMESTAMP

ratings  --  User ratings of movies
    user_id                   INT  [PK/FK -> users.user_id]
    movie_id                  INT  [PK/FK -> movies.movie_id]
    rating                    NUMERIC(2,1)
    rated_at                  DATE

waitlist  --  Users waiting for seats on sold-out shows
    waitlist_id               INT  [PK]
    user_id                   INT  [FK -> users.user_id]
    show_id                   INT  [FK -> shows.show_id]
    seats_needed              INT
    created_at                TIMESTAMP
    status                    VARCHAR(10)

HOW TO LOAD
----------------------------------------------------------------------
1. CREATE DATABASE project_db;   then design and CREATE TABLE statements yourself (PK, FK, CHECK, UNIQUE).
2. Load each CSV in the order above:
   \copy table_name FROM 'table_name.csv' WITH (FORMAT csv, HEADER true);
   (empty cells are NULL; booleans are true/false; dates are YYYY-MM-DD; timestamps are YYYY-MM-DD HH:MM:SS)
3. After loading, run ANALYZE; and verify row counts against this file.

NOTES
----------------------------------------------------------------------
* booking_seats contains rows only for confirmed bookings; cancelled bookings release their seats, so UNIQUE(show_id, seat_id) can be enforced.
