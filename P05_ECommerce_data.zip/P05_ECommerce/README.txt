PROJECT 05: E-Commerce Order and Inventory System with Redis Caching
======================================================================

Tables: 12   Total rows: 381,921

LOAD ORDER (parents before children) and ROW COUNTS
----------------------------------------------------------------------
 1. categories                    46 rows   [reference table]
 2. sellers                    1,200 rows
 3. customers                 20,000 rows
 4. addresses                 28,155 rows
 5. products                   6,000 rows
 6. inventory                 10,061 rows
 7. coupons                    1,500 rows
 8. orders                    60,000 rows
 9. order_items              108,020 rows
10. payments                  60,000 rows
11. shipments                 56,939 rows
12. reviews                   30,000 rows

COLUMNS
----------------------------------------------------------------------
categories  --  Category tree (parents and sub-categories)
    category_id               INT  [PK]
    name                      VARCHAR(40)
    parent_id                 INT  [FK -> categories.category_id]

sellers  --  Marketplace sellers
    seller_id                 INT  [PK]
    name                      VARCHAR(80)
    city                      VARCHAR(40)
    state                     VARCHAR(40)
    rating                    NUMERIC(2,1)
    joined_on                 DATE

customers  --  Registered customers
    customer_id               INT  [PK]
    full_name                 VARCHAR(80)
    email                     VARCHAR(80)
    phone                     VARCHAR(12)
    city                      VARCHAR(40)
    state                     VARCHAR(40)
    joined_on                 DATE

addresses  --  Delivery addresses
    address_id                INT  [PK]
    customer_id               INT  [FK -> customers.customer_id]
    line1                     VARCHAR(80)
    city                      VARCHAR(40)
    state                     VARCHAR(40)
    pincode                   VARCHAR(6)
    is_default                BOOLEAN

products  --  Product catalogue
    product_id                INT  [PK]
    name                      VARCHAR(90)
    category_id               INT  [FK -> categories.category_id]
    brand                     VARCHAR(30)
    price                     NUMERIC(10,2)
    mrp                       NUMERIC(10,2)
    weight_g                  INT
    created_at                DATE

inventory  --  Stock of each product per seller
    inventory_id              INT  [PK]
    product_id                INT  [FK -> products.product_id]
    seller_id                 INT  [FK -> sellers.seller_id]
    stock_qty                 INT
    reorder_level             INT
    updated_at                TIMESTAMP

coupons  --  Discount coupons
    coupon_id                 INT  [PK]
    code                      VARCHAR(20)
    discount_type             VARCHAR(10)
    discount_value            NUMERIC(8,2)
    min_order_value           NUMERIC(8,2)
    valid_from                DATE
    valid_to                  DATE
    usage_limit               INT

orders  --  Customer orders
    order_id                  INT  [PK]
    customer_id               INT  [FK -> customers.customer_id]
    address_id                INT  [FK -> addresses.address_id]
    order_ts                  TIMESTAMP
    status                    VARCHAR(12)
    coupon_id                 INT  [FK -> coupons.coupon_id]
    coupon_discount           NUMERIC(10,2)
    shipping_fee              NUMERIC(8,2)
    total_amount              NUMERIC(12,2)
    estimated_delivery        DATE

order_items  --  Line items of each order
    order_item_id             INT  [PK]
    order_id                  INT  [FK -> orders.order_id]
    product_id                INT  [FK -> products.product_id]
    seller_id                 INT  [FK -> sellers.seller_id]
    quantity                  INT
    unit_price                NUMERIC(10,2)
    discount                  NUMERIC(10,2)

payments  --  Payment per order
    payment_id                INT  [PK]
    order_id                  INT  [FK -> orders.order_id]
    method                    VARCHAR(12)
    installments              INT
    amount                    NUMERIC(12,2)
    status                    VARCHAR(10)
    paid_at                   TIMESTAMP

shipments  --  Shipment per dispatched order
    shipment_id               INT  [PK]
    order_id                  INT  [FK -> orders.order_id]
    courier                   VARCHAR(20)
    tracking_no               VARCHAR(16)
    shipped_at                TIMESTAMP
    delivered_at              TIMESTAMP
    status                    VARCHAR(12)

reviews  --  Customer reviews of purchased products
    review_id                 INT  [PK]
    order_item_id             INT  [FK -> order_items.order_item_id]
    product_id                INT  [FK -> products.product_id]
    customer_id               INT  [FK -> customers.customer_id]
    rating                    INT
    title                     VARCHAR(80)
    review_text               TEXT
    created_at                TIMESTAMP

HOW TO LOAD
----------------------------------------------------------------------
1. CREATE DATABASE project_db;   then design and CREATE TABLE statements yourself (PK, FK, CHECK, UNIQUE).
2. Load each CSV in the order above:
   \copy table_name FROM 'table_name.csv' WITH (FORMAT csv, HEADER true);
   (empty cells are NULL; booleans are true/false; dates are YYYY-MM-DD; timestamps are YYYY-MM-DD HH:MM:SS)
3. After loading, run ANALYZE; and verify row counts against this file.

NOTES
----------------------------------------------------------------------
* About 0.5% of payments deliberately differ from their order total so that the reconciliation query has something to find.
