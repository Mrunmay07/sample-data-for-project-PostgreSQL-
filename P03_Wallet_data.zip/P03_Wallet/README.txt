PROJECT 03: Digital Wallet and Banking Ledger System
======================================================================

Tables: 9   Total rows: 294,351

LOAD ORDER (parents before children) and ROW COUNTS
----------------------------------------------------------------------
 1. users                     10,000 rows
 2. merchants                  1,200 rows
 3. transaction_types              5 rows   [reference table]
 4. wallets                   10,000 rows
 5. beneficiaries             15,000 rows
 6. transactions              76,583 rows
 7. ledger_entries           147,638 rows
 8. fraud_flags                2,800 rows
 9. login_events              31,125 rows

COLUMNS
----------------------------------------------------------------------
users  --  Wallet users; user 1 is the bank settlement account
    user_id                   INT  [PK]
    full_name                 VARCHAR(80)
    phone                     VARCHAR(12)
    email                     VARCHAR(80)
    city                      VARCHAR(40)
    kyc_status                VARCHAR(12)
    created_at                TIMESTAMP

merchants  --  Users who accept payments as merchants
    merchant_id               INT  [PK]
    user_id                   INT  [FK -> users.user_id]
    business_name             VARCHAR(80)
    category                  VARCHAR(30)
    city                      VARCHAR(40)
    gst_no                    VARCHAR(15)

transaction_types  --  Reference table of transaction types
    type_id                   INT  [PK]
    type_name                 VARCHAR(20)
    description               VARCHAR(60)

wallets  --  One wallet per user; balance equals the last ledger balance_after
    wallet_id                 INT  [PK]
    user_id                   INT  [FK -> users.user_id]
    wallet_type               VARCHAR(10)
    balance                   NUMERIC(14,2)
    currency                  CHAR(3)
    status                    VARCHAR(10)
    daily_limit               NUMERIC(10,2)
    opened_at                 TIMESTAMP

beneficiaries  --  Saved payees of each user
    beneficiary_id            INT  [PK]
    user_id                   INT  [FK -> users.user_id]
    beneficiary_user_id       INT  [FK -> users.user_id]
    nickname                  VARCHAR(40)
    added_on                  DATE

transactions  --  All wallet transactions (success and failed)
    txn_id                    INT  [PK]
    type_id                   INT  [FK -> transaction_types.type_id]
    from_wallet_id            INT  [FK -> wallets.wallet_id]
    to_wallet_id              INT  [FK -> wallets.wallet_id]
    amount                    NUMERIC(12,2)
    created_at                TIMESTAMP
    status                    VARCHAR(10)
    idempotency_key           VARCHAR(20)
    channel                   VARCHAR(10)
    is_fraud                  BOOLEAN

ledger_entries  --  Double-entry ledger: one debit and one credit per successful transaction
    entry_id                  INT  [PK]
    txn_id                    INT  [FK -> transactions.txn_id]
    wallet_id                 INT  [FK -> wallets.wallet_id]
    direction                 CHAR(1)
    amount                    NUMERIC(12,2)
    created_at                TIMESTAMP
    balance_after             NUMERIC(14,2)

fraud_flags  --  Transactions flagged by fraud rules
    flag_id                   INT  [PK]
    txn_id                    INT  [FK -> transactions.txn_id]
    rule_name                 VARCHAR(30)
    risk_score                INT
    flagged_at                TIMESTAMP
    reviewed_by               VARCHAR(40)
    outcome                   VARCHAR(15)

login_events  --  Login attempts with device and city (for fraud analysis)
    event_id                  INT  [PK]
    user_id                   INT  [FK -> users.user_id]
    device_id                 VARCHAR(16)
    ip_address                VARCHAR(15)
    login_at                  TIMESTAMP
    success                   BOOLEAN
    city                      VARCHAR(40)

HOW TO LOAD
----------------------------------------------------------------------
1. CREATE DATABASE project_db;   then design and CREATE TABLE statements yourself (PK, FK, CHECK, UNIQUE).
2. Load each CSV in the order above:
   \copy table_name FROM 'table_name.csv' WITH (FORMAT csv, HEADER true);
   (empty cells are NULL; booleans are true/false; dates are YYYY-MM-DD; timestamps are YYYY-MM-DD HH:MM:SS)
3. After loading, run ANALYZE; and verify row counts against this file.
