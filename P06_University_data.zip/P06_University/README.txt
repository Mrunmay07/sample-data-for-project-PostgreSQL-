PROJECT 06: University Academic and Result Management System
======================================================================

Tables: 14   Total rows: 323,748

LOAD ORDER (parents before children) and ROW COUNTS
----------------------------------------------------------------------
 1. departments                   10 rows   [reference table]
 2. programs                      16 rows   [reference table]
 3. grade_scale                    8 rows   [reference table]
 4. rooms                        150 rows   [reference table]
 5. faculty                    1,000 rows
 6. students                  12,000 rows
 7. courses                    1,200 rows
 8. prerequisites              1,500 rows
 9. course_offerings           3,000 rows
10. timetable                  6,000 rows
11. enrollments               54,153 rows
12. assessments                9,000 rows
13. assessment_scores        157,602 rows
14. attendance                78,109 rows

COLUMNS
----------------------------------------------------------------------
departments  --  Reference table of departments
    department_id             INT  [PK]
    name                      VARCHAR(40)
    code                      VARCHAR(4)

programs  --  Reference table of degree programs
    program_id                INT  [PK]
    name                      VARCHAR(50)
    department_id             INT  [FK -> departments.department_id]
    duration_years            INT

grade_scale  --  Mapping from percentage to grade and grade points
    grade                     VARCHAR(2)  [PK]
    min_percent               NUMERIC(5,2)
    grade_points              INT

rooms  --  Classrooms and labs
    room_id                   INT  [PK]
    building                  VARCHAR(20)
    room_no                   VARCHAR(8)
    capacity                  INT
    room_type                 VARCHAR(12)

faculty  --  Teaching staff
    faculty_id                INT  [PK]
    full_name                 VARCHAR(80)
    department_id             INT  [FK -> departments.department_id]
    designation               VARCHAR(25)
    email                     VARCHAR(80)
    joined_on                 DATE

students  --  Enrolled students
    student_id                INT  [PK]
    enrollment_no             VARCHAR(14)
    full_name                 VARCHAR(80)
    gender                    CHAR(1)
    date_of_birth             DATE
    program_id                INT  [FK -> programs.program_id]
    admission_year            INT
    category                  VARCHAR(10)
    city                      VARCHAR(40)
    state                     VARCHAR(40)
    email                     VARCHAR(80)
    phone                     VARCHAR(12)
    status                    VARCHAR(10)

courses  --  Course catalogue
    course_id                 INT  [PK]
    code                      VARCHAR(10)
    title                     VARCHAR(80)
    department_id             INT  [FK -> departments.department_id]
    credits                   INT
    semester_no               INT
    is_elective               BOOLEAN

prerequisites  --  Course prerequisites (acyclic)
    course_id                 INT  [PK/FK -> courses.course_id]
    prereq_course_id          INT  [PK/FK -> courses.course_id]

course_offerings  --  A course taught by a faculty in a given term
    offering_id               INT  [PK]
    course_id                 INT  [FK -> courses.course_id]
    faculty_id                INT  [FK -> faculty.faculty_id]
    academic_year             VARCHAR(7)
    term                      VARCHAR(4)
    capacity                  INT

timetable  --  Weekly class slots; no room or faculty clash within a term
    slot_id                   INT  [PK]
    offering_id               INT  [FK -> course_offerings.offering_id]
    room_id                   INT  [FK -> rooms.room_id]
    day_of_week               INT
    start_time                TIME
    end_time                  TIME

enrollments  --  Student registration in course offerings
    enrollment_id             INT  [PK]
    student_id                INT  [FK -> students.student_id]
    offering_id               INT  [FK -> course_offerings.offering_id]
    enrolled_on               DATE
    status                    VARCHAR(10)

assessments  --  Assessments of each offering (weights add up to 100)
    assessment_id             INT  [PK]
    offering_id               INT  [FK -> course_offerings.offering_id]
    assessment_type           VARCHAR(12)
    max_marks                 INT
    weight                    INT
    due_date                  DATE

assessment_scores  --  Marks of every student in every assessment
    score_id                  INT  [PK]
    assessment_id             INT  [FK -> assessments.assessment_id]
    student_id                INT  [FK -> students.student_id]
    marks_obtained            NUMERIC(5,1)
    submitted_on              DATE
    is_late                   BOOLEAN

attendance  --  Class attendance for 2024-25 Odd term enrollments
    attendance_id             INT  [PK]
    enrollment_id             INT  [FK -> enrollments.enrollment_id]
    class_date                DATE
    status                    VARCHAR(8)

HOW TO LOAD
----------------------------------------------------------------------
1. CREATE DATABASE project_db;   then design and CREATE TABLE statements yourself (PK, FK, CHECK, UNIQUE).
2. Load each CSV in the order above:
   \copy table_name FROM 'table_name.csv' WITH (FORMAT csv, HEADER true);
   (empty cells are NULL; booleans are true/false; dates are YYYY-MM-DD; timestamps are YYYY-MM-DD HH:MM:SS)
3. After loading, run ANALYZE; and verify row counts against this file.
