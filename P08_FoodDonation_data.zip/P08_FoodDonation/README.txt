PROJECT 08: NGO Food Donation and Disaster Relief Coordination System
======================================================================

Tables: 14   Total rows: 287,691

LOAD ORDER (parents before children) and ROW COUNTS
----------------------------------------------------------------------
 1. food_categories               15 rows   [reference table]
 2. nutrients                      6 rows   [reference table]
 3. food_items                 1,500 rows
 4. food_nutrients             9,000 rows
 5. organizations              1,506 rows
 6. donors                     6,000 rows
 7. disaster_events            1,100 rows
 8. donations                 40,000 rows
 9. donation_items           100,112 rows
10. requests                  25,000 rows
11. request_items             50,163 rows
12. volunteers                 4,000 rows
13. shifts                    30,088 rows
14. deliveries                19,201 rows

COLUMNS
----------------------------------------------------------------------
food_categories  --  Reference table of food categories
    category_id               INT  [PK]
    name                      VARCHAR(30)
    typical_shelf_life_hours  INT

nutrients  --  Reference table of nutrients
    nutrient_id               INT  [PK]
    name                      VARCHAR(20)
    unit                      VARCHAR(6)

food_items  --  Food item master list
    food_id                   INT  [PK]
    name                      VARCHAR(60)
    category_id               INT  [FK -> food_categories.category_id]
    shelf_life_hours          INT
    is_vegetarian             BOOLEAN

food_nutrients  --  Nutrition values per 100 g of each food
    food_id                   INT  [PK/FK -> food_items.food_id]
    nutrient_id               INT  [PK/FK -> nutrients.nutrient_id]
    amount_per_100g           NUMERIC(8,2)

organizations  --  NGO > region > centre hierarchy
    org_id                    INT  [PK]
    parent_org_id             INT  [FK -> organizations.org_id]
    org_type                  VARCHAR(10)
    name                      VARCHAR(80)
    city                      VARCHAR(40)
    state                     VARCHAR(40)
    latitude                  NUMERIC(9,6)
    longitude                 NUMERIC(9,6)

donors  --  People and businesses donating food
    donor_id                  INT  [PK]
    donor_type                VARCHAR(15)
    name                      VARCHAR(80)
    city                      VARCHAR(40)
    state                     VARCHAR(40)
    latitude                  NUMERIC(9,6)
    longitude                 NUMERIC(9,6)
    phone                     VARCHAR(12)
    registered_on             DATE

disaster_events  --  Floods, cyclones and other disasters needing relief food
    event_id                  INT  [PK]
    event_type                VARCHAR(15)
    state                     VARCHAR(40)
    district                  VARCHAR(40)
    started_on                DATE
    ended_on                  DATE
    severity                  INT
    affected_people           INT

donations  --  Each food donation event
    donation_id               INT  [PK]
    donor_id                  INT  [FK -> donors.donor_id]
    donated_at                TIMESTAMP
    pickup_required           BOOLEAN
    status                    VARCHAR(12)

donation_items  --  Foods inside each donation with prepared and expiry time
    item_id                   INT  [PK]
    donation_id               INT  [FK -> donations.donation_id]
    food_id                   INT  [FK -> food_items.food_id]
    quantity_kg               NUMERIC(8,2)
    prepared_at               TIMESTAMP
    expiry_at                 TIMESTAMP

requests  --  Centre requests for food
    request_id                INT  [PK]
    centre_org_id             INT  [FK -> organizations.org_id]
    disaster_id               INT  [FK -> disaster_events.event_id]
    requested_at              TIMESTAMP
    needed_by                 TIMESTAMP
    urgency                   VARCHAR(10)
    beneficiaries_count       INT
    status                    VARCHAR(10)

request_items  --  Foods and quantity requested
    request_item_id           INT  [PK]
    request_id                INT  [FK -> requests.request_id]
    food_id                   INT  [FK -> food_items.food_id]
    quantity_kg               NUMERIC(8,2)

volunteers  --  Volunteers attached to centres
    volunteer_id              INT  [PK]
    full_name                 VARCHAR(80)
    org_id                    INT  [FK -> organizations.org_id]
    phone                     VARCHAR(12)
    vehicle_type              VARCHAR(10)
    joined_on                 DATE

shifts  --  Volunteer shifts; no overlap per volunteer
    shift_id                  INT  [PK]
    volunteer_id              INT  [FK -> volunteers.volunteer_id]
    shift_start               TIMESTAMP
    shift_end                 TIMESTAMP
    role                      VARCHAR(12)

deliveries  --  Pickup and delivery of donated food against request items
    delivery_id               INT  [PK]
    donation_item_id          INT  [FK -> donation_items.item_id]
    request_item_id           INT  [FK -> request_items.request_item_id]
    volunteer_id              INT  [FK -> volunteers.volunteer_id]
    picked_at                 TIMESTAMP
    delivered_at              TIMESTAMP
    quantity_kg               NUMERIC(8,2)
    status                    VARCHAR(10)

HOW TO LOAD
----------------------------------------------------------------------
1. CREATE DATABASE project_db;   then design and CREATE TABLE statements yourself (PK, FK, CHECK, UNIQUE).
2. Load each CSV in the order above:
   \copy table_name FROM 'table_name.csv' WITH (FORMAT csv, HEADER true);
   (empty cells are NULL; booleans are true/false; dates are YYYY-MM-DD; timestamps are YYYY-MM-DD HH:MM:SS)
3. After loading, run ANALYZE; and verify row counts against this file.
