PROJECT 02: Blood Bank and Donor Management System
======================================================================

Tables: 11   Total rows: 222,273

LOAD ORDER (parents before children) and ROW COUNTS
----------------------------------------------------------------------
 1. blood_groups                   8 rows   [reference table]
 2. compatibility                 27 rows   [reference table]
 3. blood_banks                1,200 rows
 4. hospitals                  1,500 rows
 5. donors                    30,000 rows
 6. donation_camps             1,500 rows
 7. donations                 49,573 rows
 8. blood_units               73,512 rows
 9. blood_requests            20,000 rows
10. allocations               39,753 rows
11. alerts                     5,200 rows

COLUMNS
----------------------------------------------------------------------
blood_groups  --  Reference table of the 8 blood groups
    group_id                  INT  [PK]
    group_name                VARCHAR(3)
    abo                       VARCHAR(2)
    rh                        CHAR(1)

compatibility  --  Which donor group can give red cells to which recipient group
    donor_group_id            INT  [PK/FK -> blood_groups.group_id]
    recipient_group_id        INT  [PK/FK -> blood_groups.group_id]

blood_banks  --  Licensed blood banks across India (generated)
    bank_id                   INT  [PK]
    name                      VARCHAR(90)
    category                  VARCHAR(15)
    state                     VARCHAR(40)
    city                      VARCHAR(40)
    pincode                   VARCHAR(6)
    latitude                  NUMERIC(9,6)
    longitude                 NUMERIC(9,6)
    phone                     VARCHAR(12)
    license_no                VARCHAR(20)
    capacity_units            INT

hospitals  --  Hospitals that request blood (generated)
    hospital_id               INT  [PK]
    name                      VARCHAR(90)
    city                      VARCHAR(40)
    state                     VARCHAR(40)
    latitude                  NUMERIC(9,6)
    longitude                 NUMERIC(9,6)
    phone                     VARCHAR(12)
    bed_count                 INT

donors  --  Registered blood donors
    donor_id                  INT  [PK]
    full_name                 VARCHAR(80)
    gender                    CHAR(1)
    date_of_birth             DATE
    group_id                  INT  [FK -> blood_groups.group_id]
    phone                     VARCHAR(12)
    city                      VARCHAR(40)
    state                     VARCHAR(40)
    registered_on             DATE
    is_active                 BOOLEAN

donation_camps  --  Voluntary blood donation camps
    camp_id                   INT  [PK]
    bank_id                   INT  [FK -> blood_banks.bank_id]
    organizer                 VARCHAR(80)
    city                      VARCHAR(40)
    camp_date                 DATE
    target_units              INT

donations  --  Each blood donation event (accepted or deferred)
    donation_id               INT  [PK]
    donor_id                  INT  [FK -> donors.donor_id]
    bank_id                   INT  [FK -> blood_banks.bank_id]
    camp_id                   INT  [FK -> donation_camps.camp_id]
    donated_on                DATE
    volume_ml                 INT
    hemoglobin                NUMERIC(4,1)
    status                    VARCHAR(10)

blood_units  --  Blood units (components) produced from accepted donations
    unit_id                   INT  [PK]
    donation_id               INT  [FK -> donations.donation_id]
    bank_id                   INT  [FK -> blood_banks.bank_id]
    group_id                  INT  [FK -> blood_groups.group_id]
    component                 VARCHAR(15)
    collected_on              DATE
    expiry_on                 DATE
    status                    VARCHAR(12)

blood_requests  --  Hospital requests for blood
    request_id                INT  [PK]
    hospital_id               INT  [FK -> hospitals.hospital_id]
    group_id                  INT  [FK -> blood_groups.group_id]
    component                 VARCHAR(15)
    units_needed              INT
    urgency                   VARCHAR(12)
    requested_at              TIMESTAMP
    status                    VARCHAR(12)

allocations  --  Units issued against requests
    allocation_id             INT  [PK]
    request_id                INT  [FK -> blood_requests.request_id]
    unit_id                   INT  [FK -> blood_units.unit_id]
    allocated_at              TIMESTAMP
    issued_by_bank_id         INT  [FK -> blood_banks.bank_id]

alerts  --  Expiry and low stock alerts
    alert_id                  INT  [PK]
    bank_id                   INT  [FK -> blood_banks.bank_id]
    unit_id                   INT  [FK -> blood_units.unit_id]
    group_id                  INT  [FK -> blood_groups.group_id]
    alert_type                VARCHAR(15)
    created_at                TIMESTAMP
    is_resolved               BOOLEAN

HOW TO LOAD
----------------------------------------------------------------------
1. CREATE DATABASE project_db;   then design and CREATE TABLE statements yourself (PK, FK, CHECK, UNIQUE).
2. Load each CSV in the order above:
   \copy table_name FROM 'table_name.csv' WITH (FORMAT csv, HEADER true);
   (empty cells are NULL; booleans are true/false; dates are YYYY-MM-DD; timestamps are YYYY-MM-DD HH:MM:SS)
3. After loading, run ANALYZE; and verify row counts against this file.
