PROJECT 09: Inventory and Supply Chain Management System
======================================================================

Tables: 14   Total rows: 407,871

LOAD ORDER (parents before children) and ROW COUNTS
----------------------------------------------------------------------
 1. departments                   12 rows   [reference table]
 2. categories                    54 rows   [reference table]
 3. warehouses                    30 rows   [reference table]
 4. suppliers                  1,200 rows
 5. products                   6,000 rows
 6. product_suppliers          8,011 rows
 7. bom                        6,791 rows
 8. customers                 15,000 rows
 9. orders                    50,000 rows
10. order_items               89,156 rows
11. shipments                 43,505 rows
12. purchase_orders            8,000 rows
13. po_lines                  24,112 rows
14. stock_ledger             156,000 rows

COLUMNS
----------------------------------------------------------------------
departments  --  Reference table of product departments
    department_id             INT  [PK]
    name                      VARCHAR(30)

categories  --  Product categories inside departments
    category_id               INT  [PK]
    department_id             INT  [FK -> departments.department_id]
    name                      VARCHAR(40)

warehouses  --  Warehouses and distribution centres
    warehouse_id              INT  [PK]
    name                      VARCHAR(40)
    city                      VARCHAR(40)
    state                     VARCHAR(40)
    zone                      VARCHAR(12)
    capacity_units            INT

suppliers  --  Suppliers
    supplier_id               INT  [PK]
    name                      VARCHAR(80)
    city                      VARCHAR(40)
    country                   VARCHAR(20)
    lead_time_days            INT
    rating                    NUMERIC(2,1)
    payment_terms             VARCHAR(10)

products  --  Finished goods, sub-assemblies and components
    product_id                INT  [PK]
    sku                       VARCHAR(12)
    name                      VARCHAR(80)
    category_id               INT  [FK -> categories.category_id]
    product_type              VARCHAR(12)
    unit_cost                 NUMERIC(10,2)
    unit_price                NUMERIC(10,2)
    reorder_level             INT
    is_perishable             BOOLEAN

product_suppliers  --  Which supplier can supply which product (many-to-many)
    product_id                INT  [PK/FK -> products.product_id]
    supplier_id               INT  [PK/FK -> suppliers.supplier_id]
    supplier_price            NUMERIC(10,2)
    min_order_qty             INT

bom  --  Bill of materials: finished goods > sub-assemblies > components
    parent_product_id         INT  [PK/FK -> products.product_id]
    component_product_id      INT  [PK/FK -> products.product_id]
    quantity                  INT

customers  --  Customers
    customer_id               INT  [PK]
    full_name                 VARCHAR(80)
    segment                   VARCHAR(12)
    city                      VARCHAR(40)
    state                     VARCHAR(40)
    zone                      VARCHAR(12)
    joined_on                 DATE

orders  --  Customer orders
    order_id                  INT  [PK]
    customer_id               INT  [FK -> customers.customer_id]
    order_date                DATE
    order_status              VARCHAR(16)
    shipping_mode             VARCHAR(15)
    zone                      VARCHAR(12)
    warehouse_id              INT  [FK -> warehouses.warehouse_id]

order_items  --  Order lines with computed profit
    order_item_id             INT  [PK]
    order_id                  INT  [FK -> orders.order_id]
    product_id                INT  [FK -> products.product_id]
    quantity                  INT
    unit_price                NUMERIC(10,2)
    discount_rate             NUMERIC(4,2)
    profit                    NUMERIC(12,2)

shipments  --  One shipment per order
    order_id                  INT  [PK/FK -> orders.order_id]
    carrier                   VARCHAR(20)
    scheduled_days            INT
    actual_days               INT
    delivery_status           VARCHAR(15)
    late_delivery_risk        BOOLEAN

purchase_orders  --  Purchase orders to suppliers
    po_id                     INT  [PK]
    supplier_id               INT  [FK -> suppliers.supplier_id]
    warehouse_id              INT  [FK -> warehouses.warehouse_id]
    po_date                   DATE
    expected_date             DATE
    received_date             DATE
    status                    VARCHAR(10)

po_lines  --  Lines of each purchase order
    po_id                     INT  [PK/FK -> purchase_orders.po_id]
    line_no                   INT  [PK]
    product_id                INT  [FK -> products.product_id]
    quantity                  INT
    unit_cost                 NUMERIC(10,2)

stock_ledger  --  Every stock in / out movement; stock = running sum
    movement_id               INT  [PK]
    product_id                INT  [FK -> products.product_id]
    warehouse_id              INT  [FK -> warehouses.warehouse_id]
    movement_type             VARCHAR(14)
    quantity_change           INT
    batch_no                  VARCHAR(12)
    expiry_date               DATE
    movement_ts               TIMESTAMP
    ref_type                  VARCHAR(8)
    ref_id                    INT

HOW TO LOAD
----------------------------------------------------------------------
1. CREATE DATABASE project_db;   then design and CREATE TABLE statements yourself (PK, FK, CHECK, UNIQUE).
2. Load each CSV in the order above:
   \copy table_name FROM 'table_name.csv' WITH (FORMAT csv, HEADER true);
   (empty cells are NULL; booleans are true/false; dates are YYYY-MM-DD; timestamps are YYYY-MM-DD HH:MM:SS)
3. After loading, run ANALYZE; and verify row counts against this file.

NOTES
----------------------------------------------------------------------
* stock_ledger.ref_type / ref_id is a polymorphic reference (PO or ORDER) and intentionally has no foreign key.
