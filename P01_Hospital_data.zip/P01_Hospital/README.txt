PROJECT 01: Hospital Management System with Secure Patient Records
======================================================================

Tables: 16   Total rows: 317,039

LOAD ORDER (parents before children) and ROW COUNTS
----------------------------------------------------------------------
 1. departments                   15 rows   [reference table]
 2. payers                        20 rows   [reference table]
 3. icd_codes                     45 rows   [reference table]
 4. lab_tests                     30 rows   [reference table]
 5. doctors                    1,200 rows
 6. staff                      1,600 rows
 7. patients                  15,000 rows
 8. patient_insurance          8,500 rows
 9. medicines                  1,500 rows
10. appointments              60,000 rows
11. admissions                 8,800 rows
12. diagnoses                 57,364 rows
13. prescriptions             30,000 rows
14. prescription_items        74,965 rows
15. lab_orders                25,000 rows
16. bills                     33,000 rows

COLUMNS
----------------------------------------------------------------------
departments  --  Reference table of hospital departments
    department_id             INT  [PK]
    name                      VARCHAR(60)
    floor_no                  INT
    phone_ext                 VARCHAR(6)

payers  --  Reference table of insurers and government schemes
    payer_id                  INT  [PK]
    name                      VARCHAR(80)
    payer_type                VARCHAR(12)
    claim_settlement_ratio    NUMERIC(5,2)

icd_codes  --  Reference table of ICD-10 diagnosis codes
    icd_code                  VARCHAR(8)  [PK]
    description               VARCHAR(80)
    is_chronic                BOOLEAN

lab_tests  --  Reference table of laboratory tests
    test_id                   INT  [PK]
    test_name                 VARCHAR(60)
    price                     NUMERIC(8,2)
    unit                      VARCHAR(12)

doctors  --  Doctors working in the hospital
    doctor_id                 INT  [PK]
    full_name                 VARCHAR(80)
    department_id             INT  [FK -> departments.department_id]
    qualification             VARCHAR(30)
    experience_years          INT
    consultation_fee          NUMERIC(8,2)
    phone                     VARCHAR(12)
    email                     VARCHAR(80)
    joined_on                 DATE

staff  --  Nurses, receptionists, pharmacists and other staff (used for RBAC)
    staff_id                  INT  [PK]
    full_name                 VARCHAR(80)
    role                      VARCHAR(20)
    department_id             INT  [FK -> departments.department_id]
    phone                     VARCHAR(12)
    hired_on                  DATE

patients  --  Registered patients
    patient_id                INT  [PK]
    full_name                 VARCHAR(80)
    gender                    CHAR(1)
    date_of_birth             DATE
    blood_group               VARCHAR(3)
    phone                     VARCHAR(12)
    email                     VARCHAR(80)
    city                      VARCHAR(40)
    state                     VARCHAR(40)
    registered_on             DATE

patient_insurance  --  Insurance policies held by patients
    policy_id                 INT  [PK]
    patient_id                INT  [FK -> patients.patient_id]
    payer_id                  INT  [FK -> payers.payer_id]
    policy_no                 VARCHAR(20)
    sum_insured               NUMERIC(10,2)
    valid_from                DATE
    valid_to                  DATE

medicines  --  Medicine master list
    medicine_id               INT  [PK]
    brand_name                VARCHAR(60)
    generic_name              VARCHAR(60)
    category                  VARCHAR(30)
    strength                  VARCHAR(12)
    manufacturer              VARCHAR(40)
    unit_price                NUMERIC(8,2)

appointments  --  Doctor appointments, 15 minute slots, no overlap per doctor
    appointment_id            INT  [PK]
    patient_id                INT  [FK -> patients.patient_id]
    doctor_id                 INT  [FK -> doctors.doctor_id]
    slot_start                TIMESTAMP
    slot_end                  TIMESTAMP
    status                    VARCHAR(12)
    reason                    VARCHAR(80)
    booked_on                 TIMESTAMP

admissions  --  In-patient admissions including some 30-day readmissions
    admission_id              INT  [PK]
    patient_id                INT  [FK -> patients.patient_id]
    doctor_id                 INT  [FK -> doctors.doctor_id]
    admitted_on               TIMESTAMP
    discharged_on             TIMESTAMP
    ward_type                 VARCHAR(15)
    bed_no                    VARCHAR(8)
    primary_icd               VARCHAR(8)  [FK -> icd_codes.icd_code]

diagnoses  --  Diagnoses recorded during appointments
    diagnosis_id              INT  [PK]
    patient_id                INT  [FK -> patients.patient_id]
    appointment_id            INT  [FK -> appointments.appointment_id]
    icd_code                  VARCHAR(8)  [FK -> icd_codes.icd_code]
    diagnosed_on              DATE
    severity                  VARCHAR(10)

prescriptions  --  Prescription header per appointment
    prescription_id           INT  [PK]
    appointment_id            INT  [FK -> appointments.appointment_id]
    patient_id                INT  [FK -> patients.patient_id]
    doctor_id                 INT  [FK -> doctors.doctor_id]
    issued_on                 DATE

prescription_items  --  Medicines on each prescription, with active date range
    item_id                   INT  [PK]
    prescription_id           INT  [FK -> prescriptions.prescription_id]
    medicine_id               INT  [FK -> medicines.medicine_id]
    dosage                    VARCHAR(12)
    start_date                DATE
    end_date                  DATE
    quantity                  INT

lab_orders  --  Laboratory tests ordered during appointments
    order_id                  INT  [PK]
    appointment_id            INT  [FK -> appointments.appointment_id]
    test_id                   INT  [FK -> lab_tests.test_id]
    ordered_on                TIMESTAMP
    result_value              NUMERIC(8,2)
    status                    VARCHAR(12)

bills  --  Bills for appointments (OPD) and admissions (IPD)
    bill_id                   INT  [PK]
    patient_id                INT  [FK -> patients.patient_id]
    appointment_id            INT  [FK -> appointments.appointment_id]
    admission_id              INT  [FK -> admissions.admission_id]
    bill_date                 DATE
    consultation_charge       NUMERIC(10,2)
    medicine_charge           NUMERIC(10,2)
    lab_charge                NUMERIC(10,2)
    room_charge               NUMERIC(10,2)
    discount                  NUMERIC(10,2)
    tax_amount                NUMERIC(10,2)
    total_amount              NUMERIC(10,2)
    payer_id                  INT  [FK -> payers.payer_id]
    insurance_covered         NUMERIC(10,2)
    payment_status            VARCHAR(10)
    payment_mode              VARCHAR(10)

HOW TO LOAD
----------------------------------------------------------------------
1. CREATE DATABASE project_db;   then design and CREATE TABLE statements yourself (PK, FK, CHECK, UNIQUE).
2. Load each CSV in the order above:
   \copy table_name FROM 'table_name.csv' WITH (FORMAT csv, HEADER true);
   (empty cells are NULL; booleans are true/false; dates are YYYY-MM-DD; timestamps are YYYY-MM-DD HH:MM:SS)
3. After loading, run ANALYZE; and verify row counts against this file.
