PROJECT 07: Digital Library and Research Paper Repository with Full-Text Search
======================================================================

Tables: 18   Total rows: 470,251

LOAD ORDER (parents before children) and ROW COUNTS
----------------------------------------------------------------------
 1. subjects                      30 rows   [reference table]
 2. publishers                    20 rows   [reference table]
 3. research_categories           30 rows   [reference table]
 4. authors                    4,000 rows
 5. papers                    30,000 rows
 6. paper_categories          50,302 rows
 7. paper_authors             93,686 rows
 8. paper_citations           60,000 rows
 9. keywords                   1,050 rows
10. paper_keywords            83,862 rows
11. books                      8,000 rows
12. book_authors              13,383 rows
13. book_copies               20,000 rows
14. members                    8,000 rows
15. issues                    46,321 rows
16. fines                      5,567 rows
17. reservations               6,000 rows
18. search_log                40,000 rows

COLUMNS
----------------------------------------------------------------------
subjects  --  Library subject classes
    subject_id                INT  [PK]
    name                      VARCHAR(40)

publishers  --  Book publishers
    publisher_id              INT  [PK]
    name                      VARCHAR(50)
    country                   VARCHAR(20)

research_categories  --  arXiv-style research categories
    category_code             VARCHAR(14)  [PK]
    name                      VARCHAR(40)

authors  --  Authors of books and research papers
    author_id                 INT  [PK]
    full_name                 VARCHAR(80)
    affiliation               VARCHAR(60)
    country                   VARCHAR(20)

papers  --  Research paper metadata with abstracts (used for full-text search)
    paper_id                  INT  [PK]
    arxiv_id                  VARCHAR(12)
    title                     VARCHAR(200)
    abstract                  TEXT
    published_on              DATE
    journal_ref               VARCHAR(60)
    doi                       VARCHAR(30)
    num_versions              INT

paper_categories  --  Categories of each paper (many-to-many)
    paper_id                  INT  [PK/FK -> papers.paper_id]
    category_code             VARCHAR(14)  [PK/FK -> research_categories.category_code]

paper_authors  --  Authors of each paper (many-to-many)
    paper_id                  INT  [PK/FK -> papers.paper_id]
    author_id                 INT  [PK/FK -> authors.author_id]
    author_order              INT

paper_citations  --  Which paper cites which (cited paper is always older)
    citing_paper_id           INT  [PK/FK -> papers.paper_id]
    cited_paper_id            INT  [PK/FK -> papers.paper_id]

keywords  --  Author keywords
    keyword_id                INT  [PK]
    keyword                   VARCHAR(40)

paper_keywords  --  Keywords of each paper (many-to-many)
    paper_id                  INT  [PK/FK -> papers.paper_id]
    keyword_id                INT  [PK/FK -> keywords.keyword_id]

books  --  Books catalogue
    book_id                   INT  [PK]
    isbn                      VARCHAR(13)
    title                     VARCHAR(120)
    subject_id                INT  [FK -> subjects.subject_id]
    publisher_id              INT  [FK -> publishers.publisher_id]
    publication_year          INT
    language                  VARCHAR(10)
    pages                     INT

book_authors  --  Authors of each book (many-to-many)
    book_id                   INT  [PK/FK -> books.book_id]
    author_id                 INT  [PK/FK -> authors.author_id]

book_copies  --  Physical copies of books
    copy_id                   INT  [PK]
    book_id                   INT  [FK -> books.book_id]
    shelf_location            VARCHAR(10)
    acquired_on               DATE
    condition                 VARCHAR(10)

members  --  Library members
    member_id                 INT  [PK]
    full_name                 VARCHAR(80)
    member_type               VARCHAR(15)
    department                VARCHAR(30)
    email                     VARCHAR(80)
    max_books                 INT
    joined_on                 DATE

issues  --  Book issue and return records (no overlap per copy)
    issue_id                  INT  [PK]
    copy_id                   INT  [FK -> book_copies.copy_id]
    member_id                 INT  [FK -> members.member_id]
    issued_on                 DATE
    due_on                    DATE
    returned_on               DATE

fines  --  Fines for late returns
    fine_id                   INT  [PK]
    issue_id                  INT  [FK -> issues.issue_id]
    days_late                 INT
    amount                    NUMERIC(8,2)
    paid_on                   DATE

reservations  --  Reservations for books that are issued out
    reservation_id            INT  [PK]
    member_id                 INT  [FK -> members.member_id]
    book_id                   INT  [FK -> books.book_id]
    reserved_on               DATE
    status                    VARCHAR(10)

search_log  --  What members searched for in the catalogue
    log_id                    INT  [PK]
    member_id                 INT  [FK -> members.member_id]
    query_text                VARCHAR(80)
    searched_at               TIMESTAMP
    results_count             INT

HOW TO LOAD
----------------------------------------------------------------------
1. CREATE DATABASE project_db;   then design and CREATE TABLE statements yourself (PK, FK, CHECK, UNIQUE).
2. Load each CSV in the order above:
   \copy table_name FROM 'table_name.csv' WITH (FORMAT csv, HEADER true);
   (empty cells are NULL; booleans are true/false; dates are YYYY-MM-DD; timestamps are YYYY-MM-DD HH:MM:SS)
3. After loading, run ANALYZE; and verify row counts against this file.
